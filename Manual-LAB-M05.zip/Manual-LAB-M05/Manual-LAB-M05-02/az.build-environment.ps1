<#	
	Version:        1.0
	Author:         Ahmad Majeed Zahoory
	Creation Date:  5th January, 2026
	Purpose/Change: Build Primary & DR Environment

#>

############################################## Variables ############################################################

# Variables for common values
$resourceGroup1 = "az-db-rg1"
$location1= "eastus"
$resourceGroup2 = "az-db-rg2"
$location2 = "eastus2"
Set-Item Env:\SuppressAzurePowerShellBreakingChangeWarnings "true"

####################################### Primary Virtual Network ######################################################

# Create a resource group
New-AzresourceGroup -Name $resourceGroup1 -location $location1

# Create a virtual network with subnet
$subnet1 = New-AzVirtualNetworkSubnetConfig -Name websubnet -AddressPrefix 192.168.0.0/24
$subnet2 = New-AzVirtualNetworkSubnetConfig -Name dBsubnet -AddressPrefix 192.168.1.0/24
$vnet1 = New-AzVirtualNetwork -resourceGroupName $resourceGroup1 -Name primary-vnet -AddressPrefix 192.168.0.0/23 `
  -location $location1 -Subnet $subnet1, $subnet2

############################################ Primary Caching Storage ########################################################

$SkuName = "Standard_LRS"
$Prefix = "labdbprimary"

#Create Storageaccount
function New-RandomName {
( -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 10 | % {[char]$_}))
}
do {
        $SARandomName = New-RandomName
        $SAName = ($Prefix + $SARandomName).ToLower()
        $Availability = Get-AzStorageAccountNameAvailability -Name $SAName
    }
while ($Availability.NameAvailable -eq $false)
    
New-AzStorageAccount -resourceGroupName $resourceGroup1 -Name $SAName -location $location1 -SkuName $SkuName

############################################ DR Virtual Network ######################################################

# Create a resource group
New-AzresourceGroup -Name $resourceGroup2 -location $location2

# Create a virtual network with subnet
$subnet1 = New-AzVirtualNetworkSubnetConfig -Name websubnet -AddressPrefix 192.168.0.0/24
$subnet2 = New-AzVirtualNetworkSubnetConfig -Name dbsubnet -AddressPrefix 192.168.1.0/24
$vnet2 = New-AzVirtualNetwork -resourceGroupName $resourceGroup2 -Name dr-vnet -AddressPrefix 192.168.0.0/23 `
  -location $location2 -Subnet $subnet1, $subnet2

 
############################################ DR Caching Storage #######################################################

$SkuName = "Standard_LRS"
$Prefix = "labdbdr"

#Create Storageaccount
function New-RandomName {
( -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 10 | % {[char]$_}))
}
do {
        $SARandomName = New-RandomName
        $SAName = ($Prefix + $SARandomName).ToLower()
        $Availability = Get-AzStorageAccountNameAvailability -Name $SAName
    }
while ($Availability.NameAvailable -eq $false)
    
New-AzStorageAccount -resourceGroupName $resourceGroup2 -Name $SAName -location $location2 -SkuName $SkuName

################################# Public IP Address for Web DR Server #################################################

# Create a public IP address and specify a DNS name
New-AzPublicIpAddress -ResourceGroupName $resourceGroup2 -Location $location2 `
  -Name "drwebsrvdns$(Get-Random)" -AllocationMethod Dynamic -IdleTimeoutInMinutes 4
  
####End